package com.deeredit.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(10, 10, 18))
        }

        val title = TextView(this).apply {
            text = "🦌 DEER EDIT"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Edit • Create • Imagine"
            textSize = 18f
            setTextColor(Color.rgb(120, 210, 255))
            gravity = Gravity.CENTER
        }

        val photo = createButton("📷 AI Photo Editor")
        val video = createButton("🎬 Video Editor")
        val prompt = createButton("✨ AI Prompt Studio")
        val templates = createButton("🎨 Templates")
        val premium = createButton("👑 Premium")

        root.addView(title)
        root.addView(subtitle)

        root.addView(photo)
        root.addView(video)
        root.addView(prompt)
        root.addView(templates)
        root.addView(premium)

        setContentView(root)
    }

    private fun createButton(textValue: String): TextView {
        return TextView(this).apply {
            text = textValue
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(20, 28, 20, 28)
        }
    }
}
